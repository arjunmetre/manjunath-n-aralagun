   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2017 Online Library Management System |<a href="https://phpgurukul.com/" target="_blank"  > Designed by : PHPGURUKUL</a> 
                </div>

            </div>
        </div>
    </section>